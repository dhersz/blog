# hugo-nanx2020

[nanx2020](https://github.com/nanxstats/hugo-nanx2020) is a Bootstrap-based, opinionated theme for Hugo. It is customized from [hugo-renga](https://github.com/nanxstats/hugo-renga) and used for [my personal website](https://nanx.me). The design inspiration comes from the [jackal theme](https://github.com/clenemt/jackal) for Jekyll.

## License

This theme is released under [MIT](https://github.com/nanxstats/hugo-nanx2020/blob/master/LICENSE).
